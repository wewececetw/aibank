$(document).ready(function(){
    
    $('#bank-account-table').DataTable( {
        responsive: true,
        paging:  false,
        info: false,
        filter: false,
    } );

    $('#history-inquire-table').DataTable( {
        responsive: true,
        paging:  false,
        info: false,
        filter: false,
    } );

});
